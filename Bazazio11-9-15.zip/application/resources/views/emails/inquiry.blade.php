<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Live stream Inquiry</h2>

		<div>
			
		</div>
	</body>
</html>
