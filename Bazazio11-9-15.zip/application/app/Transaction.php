<?php

namespace App;
use App\Model;
use Amsgames\LaravelShop\Models\ShopTransactionModel;

class Transaction extends ShopTransactionModel 
{
    //
}
