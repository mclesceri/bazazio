<?php 

namespace App;
use DB;
use Auth;

use Illuminate\Database\Eloquent\Model;

class Game extends Model {

    protected $table = 'games';

}
