<?php 

namespace App;
use DB;
use Auth;

use Illuminate\Database\Eloquent\Model;

class Livestream extends Model {

    protected $table = 'livestream';

}
