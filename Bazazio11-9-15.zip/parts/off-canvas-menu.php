<aside class="right-off-canvas-menu dark" aria-hidden="true">
    <?php dpnalibrary_2015_mobile_off_canvas(); ?>
</aside>